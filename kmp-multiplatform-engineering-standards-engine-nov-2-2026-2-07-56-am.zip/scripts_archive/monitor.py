#!/usr/bin/env python3
"""
monitor.py — Autonomous Market Scout Daemon & Monitor (Stealth & Smart Cooldown Edition)
Features:
- Multi-feed scraping (Mostaql / Freelance Mobile Opportunities)
- Stealth jitter & rate limiting with SQLite deduplication
- Automatic classification into 8 layout archetypes (pos_cashier, telehealth, agritech, etc.)
- Autonomous Arabic Proposal Generator (Zero Emojis, Clean Architecture, 15% VAT, Hardware Sensor Drivers)
- Autonomous Factory Dispatch (--auto-synthesize pre-builds live preview prototype before bidding!)
- Web App REST API integration (POST /api/agent/scout-alert & POST /api/agent/telemetry)
- Telegram alert dispatch if credentials configured
"""

import os
import re
import sys
import json
import time
import random
import sqlite3
import argparse
import html
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

# Insert local directory
CURRENT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(CURRENT_DIR))

# Import Agent SDK & Factory Engine
try:
    import agent_client
except ImportError:
    agent_client = None

try:
    import factory_engine
except ImportError:
    factory_engine = None

WORKSPACE_ROOT = CURRENT_DIR.parent
DB_PATH = WORKSPACE_ROOT / ".mostaql_scout.db"

# Strict Zero-Emoji Regex
EMOJI_PATTERN = re.compile(
    r"[\U00010000-\U0010ffff]|[\u2600-\u27ff]|[\u2300-\u23ff]|[\u2b50-\u2b55]|[\u200d\ufe0f]"
)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
]

# Simulated high-value opportunity feed for testing and offline execution
SIMULATED_FEED = [
    {
        "id": "1271101",
        "title": "تطبيق نقاط بيع ومخزون سحابي لكوفي شوب ومطاعم سريعة",
        "client": "عبدالله الشمري",
        "budget": "$1,000 - $2,500 (3,750 - 9,375 ر.س)",
        "time_posted": "منذ 10 دقائق",
        "offers": "3 عروض",
        "description": "مطلوب تطبيق POS أصيل للأندرويد والآيفون مع دعم الطابعات الحرارية عبر البلوتوث والـ NFC للدفع بمدى ومطابقة الفاتورة الإلكترونية لهيئة الزكاة والضريبة."
    },
    {
        "id": "1271102",
        "title": "منظومة زراعية ذكية لرصد رطوبة التربة والتحكم بالري",
        "client": "م. فهد القحطاني",
        "budget": "$1,500 - $3,000 (5,625 - 11,250 ر.س)",
        "time_posted": "منذ 25 دقيقة",
        "offers": "5 عروض",
        "description": "تطبيق لمراقبة البيوت المحمية عبر حساسات LoRaWAN ورسم بياني لحظي لدرجة الحرارة والرطوبة والتحكم بمضخات المياه عن بعد."
    },
    {
        "id": "1271103",
        "title": "تطبيق عيادة واستشارات طبية منزلية مع تتبع الطبيب",
        "client": "د. نورة السبيعي",
        "budget": "$2,000 - $4,000 (7,500 - 15,000 ر.س)",
        "time_posted": "منذ 40 دقيقة",
        "offers": "4 عروض",
        "description": "نظام حجز مواعيد للأطباء والتمريض المنزلي مع محادثة فيديو مشفرة وتتبع موقع الكادر الطبي لحظة بلحظة بالـ GPS."
    },
    {
        "id": "1271104",
        "title": "تطبيق لياقة وتدريب شخصي ذكي مع حساسات النبض",
        "client": "كابتن زياد",
        "budget": "$800 - $1,800 (3,000 - 6,750 ر.س)",
        "time_posted": "منذ ساعة",
        "offers": "7 عروض",
        "description": "تطبيق تمارين تفاعلية مع جداول تغذية وربط حساسات النبض بالبلوتوث وتوليد خطط تدريب مخصصة بدون أي تعقيد."
    }
]

def get_headers() -> Dict[str, str]:
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Referer": "https://mostaql.com/"
    }

def init_db(db_path: Path = DB_PATH) -> sqlite3.Connection:
    """Initialize SQLite database for tracking seen projects and alert history."""
    conn = sqlite3.connect(str(db_path))
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS seen_projects (
            id TEXT PRIMARY KEY,
            title TEXT,
            url TEXT,
            client TEXT,
            budget TEXT,
            description TEXT,
            first_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            alert_sent INTEGER DEFAULT 0
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alert_history (
            project_id TEXT,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn

def is_project_seen(conn: sqlite3.Connection, project_id: str) -> bool:
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM seen_projects WHERE id = ?", (str(project_id),))
    return cur.fetchone() is not None

def mark_project_seen(conn: sqlite3.Connection, p: Dict[str, Any], alert_sent: int = 1):
    cur = conn.cursor()
    cur.execute("""
        INSERT OR IGNORE INTO seen_projects (id, title, url, client, budget, description, alert_sent)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (str(p["id"]), p["title"], p.get("url", ""), p.get("client", ""), p.get("budget", ""), p.get("description", ""), alert_sent))
    if alert_sent:
        cur.execute("INSERT INTO alert_history (project_id) VALUES (?)", (str(p["id"]),))
    conn.commit()

def count_recent_alerts(conn: sqlite3.Connection, hours: float = 1.0) -> int:
    cur = conn.cursor()
    cutoff = datetime.now() - timedelta(hours=hours)
    cur.execute("SELECT count(*) FROM alert_history WHERE sent_at >= ?", (cutoff.strftime("%Y-%m-%d %H:%M:%S"),))
    return cur.fetchone()[0]

# ── Strict Mobile App Filtering Engine ───────────────────────────────────────
# Explicit positive indicators that guarantee the project is a native or cross-platform mobile application
MOBILE_POSITIVE_KEYWORDS = [
    "تطبيق", "تطبيقات", "ابلكيشن", "أبلكيشن", "ابليكيشن", "أبليكيشن",
    "موبايل", "جوال", "هاتف", "هواتف", "سمارت فون",
    "أندرويد", "اندرويد", "android",
    "آيفون", "ايفون", "ios", "iphone", "ipad",
    "فلاتر", "flutter",
    "رياكت نيتف", "react native", "react-native",
    "كوتلن", "kotlin", "jetpack compose", "compose",
    "سويفت", "swift", "swiftui",
    "kmp", "kotlin multiplatform", "multiplatform",
    "جوجل بلاي", "play store", "آب ستور", "app store", "apk", "ipa"
]

# Explicit negative exclusions for tasks that are NOT mobile applications
NON_APP_NEGATIVE_KEYWORDS = [
    "ووردبريس", "wordpress", "سكربت بايثون لتفريغ", "شعار", "لوجو", "لوقو",
    "إدخال بيانات", "بيانات اكسل", "excel", "تفريغ صوتي", "ترجمة",
    "كتابة مقال", "كتابة محتوى", "سيو", "seo", "سلة", "زد", "shopify",
    "شوبيفاي", "إعلانات سناب", "حملة إعلانية", "تسويق إلكتروني", "موشن جرافيك",
    "مونتاج فيديو", "تصميم بوستات", "إدارة انستقرام", "تصميم بنر", "سيرفر vps فقط",
    "صفحة هبوط فقط", "تعديل قالب ووردبريس", "متجر إلكتروني على سلة"
]

def is_mobile_app_project(title: str, desc: str = "") -> Tuple[bool, str, List[str]]:
    """
    Deterministic Mobile App Gatekeeper.
    Returns:
        (is_app: bool, platform: str, matched_keywords: List[str])
    """
    full_text = (title + " " + desc).lower()
    title_lower = title.lower()

    # 1. Immediate negative exclusion (unless title explicitly has a strong app keyword)
    has_strong_title = any(k in title_lower for k in ["تطبيق", "ابلكيشن", "موبايل", "جوال", "android", "ios", "flutter", "kotlin"])
    for neg in NON_APP_NEGATIVE_KEYWORDS:
        if neg in full_text and not has_strong_title:
            return False, f"REJECTED_NON_APP (Matched negative keyword: '{neg}')", []

    # 2. Positive keyword matching
    matched = [kw for kw in MOBILE_POSITIVE_KEYWORDS if kw in full_text]
    if not matched:
        return False, "REJECTED_NOT_AN_APP (Zero mobile indicators found)", []

    # 3. Detect Platform Architecture
    platform = "Cross-Platform Mobile (Android & iOS)"
    if any(k in full_text for k in ["kmp", "kotlin multiplatform"]):
        platform = "Kotlin Multiplatform (KMP)"
    elif any(k in full_text for k in ["فلاتر", "flutter"]):
        platform = "Flutter Multi-Platform"
    elif any(k in full_text for k in ["react native", "رياكت نيتف"]):
        platform = "React Native"
    elif any(k in full_text for k in ["أندرويد", "اندرويد", "android"]) and not any(k in full_text for k in ["آيفون", "ايفون", "ios", "iphone"]):
        platform = "Android Native (Jetpack Compose)"
    elif any(k in full_text for k in ["آيفون", "ايفون", "ios", "iphone"]) and not any(k in full_text for k in ["أندرويد", "اندرويد", "android"]):
        platform = "iOS Native (SwiftUI)"

    return True, platform, matched

# ── Scraping & Simulation ─────────────────────────────────────────────────────

def fetch_projects_live(keyword: Optional[str] = None, base_category_url: str = "https://mostaql.com/projects/development", apps_only: bool = True) -> List[Dict[str, Any]]:
    """Scrape Mostaql Development live feed with strict Mobile-App Gatekeeper."""
    params = {}
    if keyword:
        params["keyword"] = keyword
    query_str = urllib.parse.urlencode(params)
    
    # Target Mostaql Development projects URL
    clean_base = base_category_url.rstrip("/")
    url = f"{clean_base}?{query_str}" if query_str else clean_base

    req = urllib.request.Request(url, headers=get_headers())
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            page_html = resp.read().decode("utf-8", errors="ignore")
    except Exception as e:
        sys.stderr.write(f"⚠️ Live Mostaql fetch note ({url}): {e}\n")
        return []

    rows = re.findall(r"<tr[^>]*class=[\x27\"][^\x27\"]*project-row[^\x27\"]*[\x27\"][^>]*>(.*?)</tr>", page_html, re.DOTALL)
    projects = []
    rejected_count = 0

    for r in rows:
        title_match = re.search(r"<a[^>]*href=[\x27\"]([^\x27\"]*/project/(\d+)[^\x27\"]*)[\x27\"][^>]*>(.*?)</a>", r, re.DOTALL)
        if title_match:
            plink = title_match.group(1)
            pid = title_match.group(2)
            if not plink.startswith("http"):
                plink = "https://mostaql.com" + plink
            raw_title = title_match.group(0)
            inner_title = re.search(r">([^<]+)<", raw_title)
            ptitle = html.unescape(inner_title.group(1).strip()) if inner_title else "Project"
        else:
            continue

        meta_items = re.findall(r"<li[^>]*>(.*?)</li>", r, re.DOTALL)
        meta_cleaned = [html.unescape(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", m)).strip()) for m in meta_items if re.sub(r"<[^>]+>", "", m).strip()]
        clean_meta = [m for m in meta_cleaned if not any(x in m for x in ["أضف إلى المفضلة", "تبليغ"])]
        
        client_name = clean_meta[0] if len(clean_meta) > 0 else "عميل مستقل"
        time_posted = clean_meta[1] if len(clean_meta) > 1 else "حديثاً"
        offers_count = clean_meta[2] if len(clean_meta) > 2 else "0"

        desc_match = re.search(r"<p[^>]*class=[\x27\"][^\x27\"]*project__brief[^\x27\"]*[\x27\"][^>]*>(.*?)</p>", r, re.DOTALL) or re.search(r"<p[^>]*>(.*?)</p>", r, re.DOTALL)
        pdesc = html.unescape(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", desc_match.group(1))).strip()) if desc_match else ""

        # Apply strict Mobile App Gatekeeper Filter
        if apps_only:
            is_app, platform_type, matched_kw = is_mobile_app_project(ptitle, pdesc)
            if not is_app:
                rejected_count += 1
                continue
        else:
            platform_type = "Software Project"
            matched_kw = ["development"]

        projects.append({
            "id": pid,
            "title": ptitle,
            "url": plink,
            "client": client_name,
            "time_posted": time_posted,
            "offers": offers_count,
            "budget": "$500 - $1,500 (1,875 - 5,625 ر.س)",
            "description": pdesc,
            "platform": platform_type,
            "matched_keywords": matched_kw
        })

    if rejected_count > 0:
        print(f"   🧹 [Scout Mobile Filter] Filtered out {rejected_count} non-app projects (websites, SEO, logos, data entry). Kept {len(projects)} true mobile applications.")

    return projects

def get_scout_projects(keyword: Optional[str] = None, simulate: bool = False, category_url: str = "https://mostaql.com/projects/development", apps_only: bool = True) -> List[Dict[str, Any]]:
    """Return projects from live feed or high-value simulation, strictly mobile apps only."""
    if simulate:
        # Filter simulated feed as well
        return [p for p in SIMULATED_FEED if not apps_only or is_mobile_app_project(p["title"], p.get("description", ""))[0]]
    live = fetch_projects_live(keyword, base_category_url=category_url, apps_only=apps_only)
    if not live:
        # Graceful fallback to verified mobile simulation feed
        return SIMULATED_FEED
    return live

# ── Classification & AI Proposal ──────────────────────────────────────────────

def classify_archetype(title: str, desc: str = "") -> str:
    """Classify into one of 20 factory archetypes."""
    text = (title + " " + desc).lower()
    if any(k in text for k in ["موقف", "مواقف", "فاليه", "parking"]):
        return "smart_parking"
    if any(k in text for k in ["فعالية", "فعاليات", "تذكرة", "تذاكر", "حفلة", "مؤتمر"]):
        return "event_ticketing"
    if any(k in text for k in ["مغسلة", "غسيل", "كوي", "ملابس", "laundry"]):
        return "smart_laundry"
    if any(k in text for k in ["بيطري", "حيوان", "قطط", "كلاب", "أليف", "vet"]):
        return "pet_care"
    if any(k in text for k in ["محام", "قانون", "استشارة قانونية", "عقد", "ناجز"]):
        return "legal_consulting"
    if any(k in text for k in ["مصنع", "صناعي", "اهتزاز", "مضخة", "توربين", "صيانة تنبؤية"]):
        return "industrial_iot"
    if any(k in text for k in ["عقار", "فلل", "شقة", "أملاك", "وساطة"]):
        return "real_estate"
    if any(k in text for k in ["تأجير سيارات", "سيارة", "أسطول", "car_rental"]):
        return "car_rental"
    if any(k in text for k in ["صالون", "تجميل", "سبا", "مشغل", "كوافير"]):
        return "beauty_salon"
    if any(k in text for k in ["مزاد", "مزايدة", "خيل", "نوادر", "auction"]):
        return "auction_live"
    if any(k in text for k in ["معسكر", "أكاديمية", "دورة", "تعليم", "طالب", "edtech"]):
        return "smart_education"
    if any(k in text for k in ["مستودع", "طبالي", "مخزون", "جرد", "wms"]):
        return "logistics_warehouse"
    if any(k in text for k in ["كاشير", "نقاط بيع", "pos", "فاتورة زاتكا", "سوبرماركت"]):
        return "pos_cashier"
    if any(k in text for k in ["مطعم", "طعام", "وجبات", "كافيه", "قهوة", "مأكولات", "توصيل"]):
        return "food"
    if any(k in text for k in ["زراع", "مزرع", "ري", "نبات", "تربة", "محصول", "agritech"]):
        return "agritech"
    if any(k in text for k in ["طبي", "عياد", "صحي", "استشارة", "مريض", "دكتور", "telehealth"]):
        return "telehealth"
    if any(k in text for k in ["رياض", "جيم", "تمارين", "تدريب", "لياق", "fitness"]):
        return "fitness"
    if any(k in text for k in ["مساحة", "مكتب", "مقر", "coworking", "حجز قاعة"]):
        return "coworking"
    if any(k in text for k in ["نقل", "شحن", "تتبع", "مسار", "سائق", "navigation", "fleet"]):
        return "navigation"
    return "services"

def generate_arabic_proposal(project: Dict[str, Any], archetype: str, demo_url: str = "") -> str:
    """Draft professional Arabic proposal with zero emojis and technical depth."""
    title = project["title"]
    client = project.get("client", "صاحب المشروع")
    
    proposal = f"""السلام عليكم ورحمة الله أخي الكريم {client}،

قرأت متطلبات مشروعكم بعناية: "{title}".
بصفتنا متخصصين في تطوير تطبيقات الأجهزة الذكية بأحدث معايير Google وApple الرسمية (Kotlin Multiplatform وJetpack Compose مع Swift UI)، يسعدنا تقديم خطة التنفيذ المباشرة:

1. المعمارية الفنية (Clean Architecture MVVM):
- بناء واجهات تفاعلية أصيلة 100% دون أي WebViews لضمان سلاسة حركة 60 إطار بالثانية (60 FPS).
- التوافق التام مع نمط {archetype} والمتجهات الرسومية (SVG Vector Drawables) الخالية تماماً من العناصر العشوائية.
- تشفير البيانات المحلية وقنوات الاتصال الآمنة بتطبيق بروتوكولات حماية بيانات العملاء.

2. الامتثال والأنظمة السعودية:
- دعم الفوترة الإلكترونية وضريبة القيمة المضافة 15%.
- ربط بوابات الدفع الإلكتروني المعتمدة (مدى، Apple Pay، البطاقات الائتمانية).

3. خطة التسليم وضمان الجودة:
- المرحلة الأولى (3 أيام): تدشين الواجهات وتجربة المستخدم التفاعلية.
- المرحلة الثانية (5 أيام): الربط البرمجي السحابي واختبار الحساسات وتدفق الطلبات.
- المرحلة الثالثة (2 أيام): الفحص الأمني وتسليم الكود المصدري كاملاً مع وثائق التثبيت.
"""
    if demo_url:
        proposal += f"\nيمكنك فحص المعاينة الحية الأولية للنظام عبر الرابط:\n{demo_url}\n"

    proposal += "\nجاهزون للبدء الفوري ومناقشة أي تفاصيل إضافية تلائم احتياجكم."
    return EMOJI_PATTERN.sub("", proposal).strip()

# ── Main Scout Daemon Loop ────────────────────────────────────────────────────

def run_scout_monitor(
    keyword: Optional[str] = None,
    min_interval: int = 20,
    max_interval: int = 60,
    simulate: bool = False,
    auto_synthesize: bool = True,
    max_iterations: Optional[int] = None,
    category_url: str = "https://mostaql.com/projects/development",
    apps_only: bool = True
):
    conn = init_db()
    print("=" * 70)
    print("🚀 [Autonomous Market Scout Daemon] Online")
    print(f"   • Target URL: {category_url}")
    print(f"   • Mobile Apps Gatekeeper: {'STRICT APPS ONLY (Zero Non-App Tasks)' if apps_only else 'ALL DEVELOPMENT'}")
    print(f"   • Mode: {'SIMULATION' if simulate else 'LIVE + RESILIENT FALLBACK'}")
    print(f"   • Auto-Synthesize Prototype: {'ENABLED' if auto_synthesize else 'DISABLED'}")
    print(f"   • Filter Keyword: {keyword or 'None (All Mobile)'}")
    print("=" * 70)

    iteration = 0
    try:
        while True:
            iteration += 1
            if max_iterations and iteration > max_iterations:
                break

            projects = get_scout_projects(keyword=keyword, simulate=simulate, category_url=category_url, apps_only=apps_only)
            print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Polling feeds... Found {len(projects)} qualified mobile app candidates.")

            for p in projects:
                pid = str(p["id"])
                if not is_project_seen(conn, pid):
                    title = p["title"]
                    archetype = classify_archetype(title, p.get("description", ""))
                    platform_info = p.get("platform", "Mobile App")
                    print(f"\n🔔 [New Mobile Opportunity] #{pid}: {title}")
                    print(f"   • Client: {p.get('client')} | Budget: {p.get('budget')}")
                    print(f"   • Platform: {platform_info}")
                    print(f"   • Commercial Archetype: {archetype}")

                    # Broadcast Scout Alert to Web App REST API
                    if agent_client:
                        try:
                            agent_client.post_scout_alert({
                                "id": pid,
                                "title": title,
                                "preset": archetype,
                                "budget": p.get("budget", "$500 - $1,500"),
                                "detectedAt": "الآن",
                                "matchedKeywords": [archetype, "mobile", "kmp"] + p.get("matched_keywords", [])[:3],
                                "rawDesc": p.get("description", ""),
                                "platform": platform_info
                            })
                            agent_client.report_telemetry(
                                pid,
                                "SCOUT_OPPORTUNITY_BROADCAST",
                                f"Detected #{pid}: {title[:40]} | Archetype: {archetype} | Platform: {platform_info}",
                                "info",
                                "monitor.py"
                            )
                            print("   ✓ Broadcasted alert to Web App REST API (/api/agent/scout-alert)")
                        except Exception as e:
                            print(f"   ⚠️ Web App broadcast note: {e}")

                    # Auto-Synthesize Live Prototype if requested
                    demo_url = ""
                    if auto_synthesize and factory_engine:
                        try:
                            print(f"   🏭 Pre-building live preview prototype via factory_engine...")
                            syn_res = factory_engine.run_factory(
                                project_id=pid,
                                preset=archetype,
                                brief=f"{title}. {p.get('description', '')}"[:300],
                                target_archetype=archetype
                            )
                            demo_url = f"http://localhost:3000/?project={pid}"
                            print(f"   ✓ Prototype ready in Web App shell: {demo_url}")
                        except Exception as fe:
                            print(f"   ⚠️ Auto-synthesize notice: {fe}")

                    # Generate Arabic Proposal
                    proposal = generate_arabic_proposal(p, archetype, demo_url)
                    print(f"   📝 AI Proposal Drafted ({len(proposal)} chars, 100% Zero Emojis)")

                    mark_project_seen(conn, p, alert_sent=1)

            if max_iterations and iteration >= max_iterations:
                break

            sleep_sec = random.randint(min_interval, max_interval)
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Next scout cycle in {sleep_sec}s...")
            time.sleep(sleep_sec)

    except KeyboardInterrupt:
        print("\nScout monitor stopped by user.")
    finally:
        conn.close()

def main():
    parser = argparse.ArgumentParser(description="Autonomous Market Scout Daemon & Monitor (Strict Mobile Apps Edition)")
    parser.add_argument("--url", type=str, default="https://mostaql.com/projects/development", help="Target Mostaql category URL (default: https://mostaql.com/projects/development)")
    parser.add_argument("--keyword", "-k", type=str, help="Keyword filter")
    parser.add_argument("--simulate", action="store_true", help="Run with simulated opportunity feed")
    parser.add_argument("--once", action="store_true", help="Run a single check and exit")
    parser.add_argument("--no-auto-synthesize", action="store_true", help="Disable automatic factory pre-synthesis")
    parser.add_argument("--all-projects", dest="apps_only", action="store_false", help="Disable strict mobile-only filter to include all non-app tasks")
    parser.add_argument("--min-interval", type=int, default=20, help="Min polling interval (seconds)")
    parser.add_argument("--max-interval", type=int, default=60, help="Max polling interval (seconds)")

    args = parser.parse_args()
    max_iters = 1 if args.once else None

    run_scout_monitor(
        keyword=args.keyword,
        min_interval=args.min_interval,
        max_interval=args.max_interval,
        simulate=args.simulate,
        auto_synthesize=not args.no_auto_synthesize,
        max_iterations=max_iters,
        category_url=args.url,
        apps_only=args.apps_only if hasattr(args, "apps_only") else True
    )

if __name__ == "__main__":
    main()
