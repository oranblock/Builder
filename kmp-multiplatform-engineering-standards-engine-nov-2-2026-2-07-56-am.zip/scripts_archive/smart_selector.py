#!/usr/bin/env python3
"""
smart_selector.py — Autonomous Smart Preset Selector for Swarm AI Agents.
Zero-Human-Interaction tool that analyzes any client brief or freelance posting,
matches it to the optimal commercial archetype from the 20-fleet matrix,
binds the physical hardware sensor driver, computes non-colliding design metrics,
and optionally triggers instant factory synthesis.
"""

import sys
import os
import json
import urllib.request
import urllib.parse
import argparse
import subprocess
from pathlib import Path

# Port resolution:
# The user uses:
# Port 3000: Tachyon Web Server
# Port 5000: File Uploader Service
# Port 8888: SearXNG Search Engine
# Port 20128: OmniRoute AI Gateway and Dashboard
# Port 20131: OmniRoute Internal Worker
# Port 20132: OmniRoute Internal Proxy
# Factory Default: Port 3030 (or FACTORY_PORT or 3000 in container)

def get_server_url(preferred_port=None) -> str:
    if os.environ.get("FACTORY_API_BASE_URL"):
        return os.environ.get("FACTORY_API_BASE_URL").rstrip("/")
    port = preferred_port or os.environ.get("FACTORY_PORT") or "3000"
    return f"http://localhost:{port}"

# Fallback in-process 20-archetype matching matrix
ARCHETYPE_RULES = {
    "pos_cashier": (['كاشير', 'نقاط بيع', 'pos', 'فاتورة', 'زاتكا', 'باركود', 'سوبرماركت', 'مخبز'], "ESC/POS Thermal Receipt Printer + Barcode Scanner"),
    "navigation": (['ملاحة', 'بوصلة', 'صحراء', 'تخييم', 'بر', 'مسار', 'gpx', 'أقمار'], "GPS RTK High-Precision Receiver + Gyroscope"),
    "services": (['صيانة', 'سباكة', 'كهرباء', 'تكييف', 'فني', 'تسريب', 'بلاغ', 'طوارئ'], "Mada Contactless EMV L2 NFC + GPS Dispatch"),
    "fitness": (['لياقة', 'جيم', 'تمارين', 'رياضة', 'ميزان', 'وزن', 'سعرات', 'عضلات'], "BLE Smart Scale GATT 0x181D + Heart Rate Strap"),
    "food": (['طعام', 'وجبات', 'مطعم', 'مأكولات', 'فائض', 'سلة', 'حفظ النعمة', 'برجر'], "Kitchen Display System (KDS) TCP/IP Print Server"),
    "coworking": (['مكتب', 'مساحة عمل', 'قاعة', 'اجتماع', 'كوويرك', 'حجز مكاتب'], "13.56 MHz RFID Turnstile Access + TOTP Pass"),
    "telehealth": (['طبيب', 'عيادة', 'صحة', 'ضغط دم', 'نبض', 'أكسجين', 'استشارة طبية', 'وصفة'], "BLE Blood Pressure & Pulse Oximeter GATT 0x1810"),
    "agritech": (['زراعة', 'مزرعة', 'ري المحاصيل', 'شبكات ري', 'تربة', 'نخيل', 'بيوت محمية'], "LoRaWAN Soil Moisture Node + Solenoid Valve Relays"),
    "real_estate": (['عقار', 'عقارات', 'فيلا', 'شقة', 'بنتهاوس', 'أملاك', 'صك', 'وسيط', 'إفراغ', 'برج'], "360 LiDAR Spatial Scanner + Matterport Pro3"),
    "car_rental": (['سيارة', 'سيارات', 'تأجير', 'أسطول', 'تم', 'تفويض', 'مفتاح رقمي', 'obd'], "OBD-II CAN-Bus Telematics + BLE Digital Key Fob"),
    "beauty_salon": (['صالون', 'تجميل', 'سبا', 'مكياج', 'شعر', 'بشرة', 'أظافر', 'عناية'], "UV-C Chamber Sanitation IoT Sensor"),
    "auction_live": (['مزاد', 'مزايدة', 'خيل', 'نوادر', 'مطرقة', 'شيك مصدق', 'لوحة مميزة'], "BLE Hardware Bidding Paddle GATT + Sub-100ms WebRTC Audio"),
    "smart_education": (['تعليم', 'تدريب', 'دورة', 'معسكر', 'معهد', 'طالب', 'شهادة', 'قلم ذكي'], "Smart Stylus Digitizer 4096-Level + BLE Beacon"),
    "logistics_warehouse": (['مستودع', 'مخزن', 'طبلية', 'جرد', 'شحنة', 'باركود', 'wms', 'ميزان'], "2D Long-Range Laser Scanner + Bluetooth Pallet Scale"),
    "smart_parking": (['موقف', 'مواقف', 'فاليه', 'بوابة مواقف', 'حاجز', 'لوحات سيارات', 'parking'], "Ultrasonic Ground Occupancy Sensor + ANPR LPR Camera"),
    "event_ticketing": (['فعالية', 'فعاليات', 'مؤتمر', 'تذكرة', 'تذاكر', 'حفلة', 'معرض', 'ticket'], "2D Turnstile QR Scanner + UHF RFID Wristband Programmer"),
    "smart_laundry": (['مغسلة', 'غسيل', 'كوي', 'ملابس', 'تنظيف جاف', 'أثواب', 'laundry'], "Heat-Resistant RFID Garment Chips + Automated Sorter"),
    "pet_care": (['بيطري', 'عيادة بيطرية', 'حيوانات', 'قطط', 'كلاب', 'أليف', 'شريحة حيوان'], "ISO 11784/11785 134.2 kHz RFID Microchip Reader"),
    "legal_consulting": (['محام', 'محامي', 'قانون', 'استشارة قانونية', 'عقد', 'توثيق', 'ناجز'], "FIPS 140-2 Cryptographic HSM Security Token"),
    "industrial_iot": (['مصنع', 'صناعي', 'اهتزاز', 'معدات', 'مضخة', 'توربين', 'مرافق', 'صيانة تنبؤية'], "3-Axis Vibration Accelerometer + Modbus RS485 Acoustic Probe")
}

def resolve_preset_offline(brief: str) -> dict:
    lower_b = brief.lower()
    best_arch = "services"
    max_matches = 0
    matched_kws = []

    for arch, (keywords, hardware) in ARCHETYPE_RULES.items():
        found = [k for k in keywords if k in lower_b]
        if len(found) > max_matches:
            max_matches = len(found)
            best_arch = arch
            matched_kws = found

    confidence = min(0.99, 0.60 + max_matches * 0.08) if max_matches > 0 else 0.50
    hardware = ARCHETYPE_RULES[best_arch][1]

    return {
        "status": "RESOLVED_LOCALLY",
        "selected_archetype": best_arch,
        "confidence_score": round(confidence, 2),
        "hardware_peripheral": hardware,
        "matched_keywords": matched_kws
    }

def smart_select_preset(brief: str, port=None) -> dict:
    url = f"{get_server_url(port)}/api/agent/smart-select"
    payload = json.dumps({"brief": brief}).encode("utf-8")
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})

    try:
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data
    except Exception:
        # Graceful fallback to embedded local engine
        return resolve_preset_offline(brief)

def main():
    parser = argparse.ArgumentParser(description="Smart Autonomous Preset Selector (Zero-Human Interaction)")
    parser.add_argument("brief", nargs="?", help="Project brief or client request text")
    parser.add_argument("--brief", dest="opt_brief", type=str, help="Project brief flag")
    parser.add_argument("--auto-synthesize", action="store_true", help="Immediately synthesize working code & preview after selection")
    parser.add_argument("--port", type=str, default=None, help="Port to target (default: 3000 in container, or FACTORY_PORT 3030)")

    args = parser.parse_args()
    brief_text = args.brief or args.opt_brief

    if not brief_text:
        print("Usage: python3 scripts_archive/smart_selector.py '<ARABIC_OR_ENGLISH_BRIEF>' [--auto-synthesize]")
        sys.exit(1)

    print("\n🧠 [Smart Preset Selector] Analyzing Client Brief (Zero-Human Mode)...")
    print(f"📝 Brief: {brief_text[:80]}...")

    result = smart_select_preset(brief_text, port=args.port)
    arch = result.get("selected_archetype", "services")
    confidence = result.get("confidence_score", 0.95)
    hardware = result.get("hardware_peripheral", "Standard Hardware Sensor")
    matched = result.get("matched_keywords", [])

    print("\n🎯 [Autonomous Decision Result]:")
    print(f"   • Selected Commercial Archetype: \033[92m{arch}\033[0m")
    print(f"   • Confidence Score:              \033[93m{int(confidence * 100)}%\033[0m")
    print(f"   • Bound Hardware Peripheral:     \033[96m{hardware}\033[0m")
    print(f"   • Matched Semantic Keywords:     {', '.join(matched) if matched else 'Domain General'}")

    cli_cmd = result.get("zero_human_cli_command")
    if not cli_cmd:
        gen_id = str(int(1275000 + (hash(brief_text) % 4999)))
        cli_cmd = f"python3 scripts_archive/factory_engine.py {gen_id} {arch} \"{brief_text}\""

    print(f"\n⚡ Zero-Human CLI Execution Command:\n   \033[94m{cli_cmd}\033[0m\n")

    if args.auto_synthesize:
        print("🚀 [--auto-synthesize enabled] Handing off to Factory Engine...")
        gen_id = str(int(1275000 + (abs(hash(brief_text)) % 4999)))
        factory_script = Path(__file__).parent / "factory_engine.py"
        cmd = [sys.executable, str(factory_script), gen_id, arch, brief_text]
        subprocess.run(cmd, check=True)

if __name__ == "__main__":
    main()
