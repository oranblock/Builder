# 🏗️ Autonomous Ephemeral Software Factory — Master Floor Plan (v2.5 Upgrade)

## 🎯 Architecture Philosophy
- **Zero Local Disk Bloat**: Build in `/tmp/factory_<project_id>`, validate, push spec to `live-previews/specs/<id>.json`, log to SQLite vault, and purge temporary build artifacts.
- **Universal JSON Preview Engine**: The web dashboard renders live interactive native mobile frames dynamically from `UniversalAppSpec` JSON without needing to compile slow web bundles.
- **8 Commercial Archetypes & Physical Hardware Drivers**: Every synthesized application is bound to a tangible hardware peripheral (Thermal Printer, Mada Contactless NFC, GPS RTK, LoRaWAN, BLE Oximeter, RFID) rather than passive mock screens.
- **Automated Forensic Quality Governance**: Every generation is scrutinized by a 6-pillar audit enforcing the Zero-Emoji Law, WCAG 2.1 AAA contrast, dHash structural novelty, and SAR commercial valuation.
- **Autonomous Scout-to-Prototype Pipeline**: High-budget Mostaql freelance leads are discovered, matched to an archetype, synthesized into working code and preview links, and pitched with professional Arabic proposals.

---

## 🏛️ Factory Phase Breakdown

### Phase 1: The SQLite Vault (Memory & Deduplication)
**Goal**: Permanent persistent memory of all synthesized templates, preventing duplication across freelance cohorts.
- Database: `~/.template_factory.db`
- Table: `completed_templates` (tracks `project_id`, `niche_slug`, `preset`, `commit_hash`, `live_demo_url`, `maturity_level`, `created_at`).
- Embedding Deduplication: Compares project features against previous jobs to ensure visual and functional novelty.

### Phase 2: The Universal JSON Preview Engine (8 Archetypes)
**Goal**: Provide instant interactive mobile frames for clients and owners across 8 rich archetypes.
1. `pos_cashier`: Retail & Supermarket POS with ESC/POS Thermal Receipt Printer.
2. `navigation`: Logistics & Fleet Tracking with GPS RTK high-precision navigation.
3. `services`: On-demand Home & Field Maintenance with Mada EMV L2 Contactless NFC.
4. `fitness`: Athletic Club & Workout Tracker with Bluetooth BLE Heart Rate monitor.
5. `food`: Cloud Kitchen & Restaurant Order Dispatcher with Kitchen Display System (KDS).
6. `coworking`: Smart Desk & Meeting Room Access with 13.56 MHz RFID / NFC door lock.
7. `telehealth`: Clinic & Remote Patient Vitals with Bluetooth BLE Pulse Oximeter.
8. `agritech`: Smart Greenhouse & Date Palm Farms with LoRaWAN Soil Moisture telemetry.

### Phase 3: The 5-Phase Autonomous Synthesis Pipeline (`factory_engine.py`)
**Goal**: Turn a client brief into complete Android Kotlin MAD code and preview specs in seconds.
- **Step 3.1 (Archetype & Sensor Binding)**: Matches brief keywords to the optimal archetype, primary color palette, and hardware driver.
- **Step 3.2 (Spec Generation)**: Emits compliant `UniversalAppSpec` and registers it in `user_factory_archive/live-previews/specs/<project_id>.json`.
- **Step 3.3 (Kotlin MAD Jetpack Compose Generation)**: Generates `MainActivity.kt`, domain ViewModels, and the real hardware driver `SensorDriver.kt`.
- **Step 3.4 (Arabic Bid Proposal)**: Creates `PROPOSAL_AR.md` with formal corporate Arabic, 3 delivery milestones, SAR pricing, and live demo link.
- **Step 3.5 (SQLite Indexing & Web Telemetry)**: Inserts the template into the vault and broadcasts telemetry to `POST /api/agent/telemetry`.

### Phase 4: Six-Pillar Forensic Quality Audit (`board_owner_audit.py`)
**Goal**: Zero-tolerance governance to guarantee every client-facing asset is agency-grade.
- **Pillar 1 (Zero-Emoji Law)**: Rejects infantile emojis (🍔, 🚀, 📱, ✨); enforces industrial SVG tokens and semantic Lucide icons.
- **Pillar 2 (WCAG 2.1 Contrast Math)**: Validates relative luminance ratio $\ge 4.5:1$ for readable text.
- **Pillar 3 (Structural Novelty)**: dHash visual layout fingerprinting ensures similarity between applications remains $< 82\%$.
- **Pillar 4 (Clean Architecture & Hardware)**: Verifies hardware driver integration and clean MVVM separation.
- **Pillar 5 (SAR Commercial Valuation)**: Validates that deliverable scope aligns with realistic agency budgets (5,000 - 35,000 SAR).
- **Pillar 6 (Headmaster Final Grading)**: Issues letter grades (A+ to F). Generates `/board_audits/COHORT_1_GOVERNANCE_REPORT.md`.

### Phase 5: Autonomous Freelance Scout (`monitor.py`)
**Goal**: Monitor freelance platforms (Mostaql), alert the dashboard, and auto-synthesize prototypes before bidding.
- Scrapes project titles, client budgets, and project descriptions.
- Runs with `--simulate` for automated offline testing and verification.
- With `--auto-synthesize`, triggers `factory_engine.py` directly for any matched job, generating live demos and ready-to-paste proposals.
- Broadcasts high-value opportunities to `POST /api/agent/scout-alert`.

### Phase 6: Real-Time Web Telemetry Bridge (`agent_client.py`)
**Goal**: Seamless REST communication between background Python workers and the web dashboard.
- Hosts REST endpoints:
  - `POST /api/agent/telemetry`: Project health, contrast score, and sensor metrics.
  - `POST /api/agent/scout-alert`: Incoming opportunity stream.
  - `GET /api/projects`: Fleet discovery.

---

## 🚀 Execution Runbook for Terminal Agents

```bash
# Synthesize an app from a client brief:
python3 scripts_archive/factory_engine.py 1271105 telehealth "عيادة استشارية مع جهاز قياس نبض وتأكسج بلوتوث"

# Audit all generated projects:
python3 scripts_archive/board_owner_audit.py --all --no-telegram

# Scout freelance leads and auto-synthesize prototypes:
python3 scripts_archive/monitor.py --simulate --auto-synthesize --once

# Verify client SDK connectivity:
python3 scripts_archive/agent_client.py
```
