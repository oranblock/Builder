const fs = require('fs');
const path = require('path');
const { chromium } = require('/root/termux-cwd/node_modules/playwright');

const PROJECTS_DIR = '/root/mostaql-mad-android-suite/projects';
const PREVIEWS_DIR = '/root/big project/live-previews';
const SHOTS_DIR = path.join(PREVIEWS_DIR, 'shots');
const SPECS_DIR = path.join(PREVIEWS_DIR, 'specs');

fs.mkdirSync(SHOTS_DIR, { recursive: true });
fs.mkdirSync(SPECS_DIR, { recursive: true });

async function capture() {
  const browser = await chromium.launch({
    executablePath: '/usr/bin/chromium',
    args: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage']
  });

  const dirs = fs.readdirSync(PROJECTS_DIR).filter(d => fs.statSync(path.join(PROJECTS_DIR, d)).isDirectory());

  for (const dir of dirs) {
    const projPath = path.join(PROJECTS_DIR, dir);
    const demoHtml = path.join(projPath, 'demo', 'index.html');
    if (!fs.existsSync(demoHtml)) {
      console.log(`Skipping ${dir} (no demo/index.html)`);
      continue;
    }

    const projectId = dir.split('_')[0];
    console.log(`📸 Capturing screenshots for #${projectId} (${dir})...`);

    const page = await browser.newPage({ viewport: { width: 412, height: 892 } });
    await page.goto(`file://${demoHtml}`, { waitUntil: 'load' });
    await page.waitForTimeout(600);

    // Shot 1: Home View
    const shot1 = path.join(SHOTS_DIR, `${projectId}_01.png`);
    await page.screenshot({ path: shot1 });

    // Shot 2: Secondary View / Click interaction
    const shot2 = path.join(SHOTS_DIR, `${projectId}_02.png`);
    try {
      await page.evaluate(() => {
        // Try switching to secondary tab or clicking an action
        if (typeof switchTab === 'function') {
          switchTab('tracking') || switchTab('cart') || switchTab('details') || switchTab('search');
        } else {
          const card = document.querySelector('.card, [onclick*="Modal"], [onclick*="open"], [onclick*="Detail"]');
          if (card) card.click();
        }
      });
      await page.waitForTimeout(500);
    } catch (e) {}
    await page.screenshot({ path: shot2 });

    // Shot 3: Interactive modal / action
    const shot3 = path.join(SHOTS_DIR, `${projectId}_03.png`);
    try {
      await page.evaluate(() => {
        const btn = document.querySelector('button[onclick*="order"], button[onclick*="Order"], button[onclick*="submit"], button[onclick*="Submit"], [onclick*="Emergency"], [onclick*="Modal"]');
        if (btn) btn.click();
      });
      await page.waitForTimeout(500);
    } catch (e) {}
    await page.screenshot({ path: shot3 });

    await page.close();

    console.log(`  ✓ Generated 3 PNG screenshots for #${projectId}`);
  }

  await browser.close();
  console.log('🎉 All project screenshots captured successfully!');
}

capture().catch(err => {
  console.error('Fatal capture error:', err);
  process.exit(1);
});
