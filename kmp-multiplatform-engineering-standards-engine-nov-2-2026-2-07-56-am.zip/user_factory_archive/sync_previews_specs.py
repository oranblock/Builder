#!/usr/bin/env python3
"""
sync_previews_specs.py — Sync real project data and screenshots into live-previews.
"""

import os
import sys
import json
import os
import sys
import json
import urllib.request
import urllib.error
from pathlib import Path

CURRENT_DIR = Path(__file__).resolve().parent
LOCAL_SPECS_DIR = CURRENT_DIR / "live-previews" / "specs"
LOCAL_SPECS_DIR.mkdir(parents=True, exist_ok=True)

# Also check root if present
ROOT_PREVIEWS_DIR = Path("/root/big project/live-previews")
SPECS_DIR = LOCAL_SPECS_DIR
if ROOT_PREVIEWS_DIR.exists():
    SPECS_DIR = ROOT_PREVIEWS_DIR / "specs"
    SPECS_DIR.mkdir(parents=True, exist_ok=True)

API_BASE_URL = os.environ.get("FACTORY_API_BASE_URL", "http://localhost:3000").rstrip("/")


# Import config from filler
sys.path.append("/root/mostaql-mad-android-suite/.agents/skills/filler/scripts")
try:
    from config_example import PROJECTS
except ImportError:
    try:
        from config import PROJECTS
    except ImportError:
        PROJECTS = []

projects_by_dir = {p["dir"]: p for p in PROJECTS}

# Project specific Arabic titles and descriptions
PROJECT_DETAILS = {
    "1265226": {
        "title": "تطبيق تسليح — خدمات الصيانة المنزلية والسباكة والكهرباء",
        "tagline": "فنيون معتمدون، تسعير فوري، وتتبع لحظي لموقع الفني على الخريطة",
        "preset": "services",
        "theme": {"primary_color": "#0f766e", "accent_color": "#f59e0b"},
        "desc": "منصة رقمية متكاملة لطلب وحجز خدمات الصيانة المنزلية الطارئة والروتينية (كهرباء، سباكة، تكييف، أجهزة منزلية). يتميز التطبيق بنظام توجيه ذكي للفني الأقرب عبر GPS، اعتماد أوامر العمل والقطع بفاتورة رقمية دقيقة، وتأكيد الدفع عبر رمز OTP لضمان حقوق العميل والفني."
    },
    "1266029": {
        "title": "دليل الصحراء — نظام الملاحة والمسارات البرية دون اتصال",
        "tagline": "ملاحة دقيقة عبر الأقمار الصناعية وحساب المسارات الحية بدون الحاجة لإنترنت",
        "preset": "standard",
        "theme": {"primary_color": "#b45309", "accent_color": "#0ea5e9"},
        "desc": "تطبيق ملاحة وتوجيه بري متخصص لمرتادي الصحراء وهواة الرحلات البرية والتخييم في المملكة. يعمل بكفاءة 100% دون اتصال بشبكة الإنترنت مع دعم تصدير واستيراد مسارات GPX، بوصلة جيروسكوبية مدمجة، وحساب دقيق لنقاط الاهتمام ومسارات الطوارئ (SOS)."
    },
    "1266248": {
        "title": "تطبيق صحتي — دليل الأطباء وحجز المواعيد والاستشارات الطبية",
        "tagline": "ابحث عن نخبة الأطباء، احجز موعدك فورياً، وتصفح التقييمات المعتمدة",
        "preset": "services",
        "theme": {"primary_color": "#0284c7", "accent_color": "#14b8a6"},
        "desc": "تطبيق متكامل لحجز وإدارة المواعيد الطبية والبحث في دليل الأطباء والمراكز الصحية حسب التخصص والموقع الجغرافي. يوفر النظام قاعدة بيانات مشفرة وسريعة لملفات المرضى، إمكانية العمل دون اتصال للاطلاع على بيانات الأطباء السابقة، ونظام تأكيد فوري يمنع التكرار."
    },
    "1266318": {
        "title": "دكان كاشير — نقاط البيع والفوترة الإلكترونية المتوافقة مع زاتكا",
        "tagline": "نظام كاشير مالي وإدارة مخزون متوافق مع متطلبات المرحلة الثانية لهيئة الزكاة (ZATCA)",
        "preset": "ecommerce",
        "theme": {"primary_color": "#1d4ed8", "accent_color": "#16a34a"},
        "desc": "نظام نقاط بيع سحابي خفيف وسريع للمحلات التجارية والمتاجر المتنقلة، يتضمن مسح الباركود بالكاميرا، طباعة الفواتير عبر طابعات البلوتوث ESC/POS، وإنشاء رمز الاستجابة السريعة المشفر بنظام TLV المتوافق مع متطلبات هيئة الزكاة والضريبة والجمارك بالمملكة."
    },
    "1266494": {
        "title": "منصة عقدي — توثيق العقود والاتفاقيات والتوقيع الرقمي",
        "tagline": "صياغة وتوقيع العقود القانونية مع التشفير والتوقيع البيومتري المعتمد",
        "preset": "standard",
        "theme": {"primary_color": "#312e81", "accent_color": "#ca8a04"},
        "desc": "تطبيق قانوني لإدارة وتوثيق العقود بين الأطراف، يعتمد على التشفير غير المتماثل (Asymmetric Cryptography) لضمان عدم التلاعب ببنود العقد وحساب البصمة الرقمية (SHA-256). يدعم التوقيع الرقمي للطرفين وإصدار شهادة صحة الوثيقة بصيغة PDF معتمدة."
    },
    "1266544": {
        "title": "سوق بلاتينيوم — منصة الإعلانات المبوبة وتجارة السلع المستعملة",
        "tagline": "بيع واشترِ كل ما تحتاجه مع التواصل المباشر ونظام المحفظة الآمنة",
        "preset": "ecommerce",
        "theme": {"primary_color": "#4338ca", "accent_color": "#ec4899"},
        "desc": "تطبيق سوق تجاري متكامل لعرض وطلب السلع الجديدة والمستعملة والسيارات والعقارات. يشمل محرك بحث جغرافي وتصفية متقدمة حسب المدينة والفئة، نظام محادثة فورية مدمج بين البائع والمشتري، وتوثيق أمني للحسابات ضد الاحتيال."
    },
    "1270416": {
        "title": "تطبيق لياقة — التدريب الرياضي الذكي ومتابعة الخطط الغذائية",
        "tagline": "برامج تدريب مخصصة، حساب السعرات الحرارية، وتمارين بالفيديو مع مدربك الشخصي",
        "preset": "standard",
        "theme": {"primary_color": "#dc2626", "accent_color": "#f97316"},
        "desc": "منصة تدريب لياقة بدنية وتغذية تقدم جداول تمارين حركية مصورة بالفيديو، تتبع الوزن والسعرات اليومية، وتنبيهات شرب الماء والنشاط البدني مع دعم كامل للاتصال بساعات اللياقة وأجهزة الاستشعار عبر Health Connect."
    },
    "1270493": {
        "title": "مكتب — حجز مساحات العمل المشتركة وقاعات الاجتماعات",
        "tagline": "احجز مكتبك أو قاعتك المفضلة بالساعة أو اليوم مع الدفع الرقمي والإنترنت الفائق",
        "preset": "services",
        "theme": {"primary_color": "#0d9488", "accent_color": "#eab308"},
        "desc": "تطبيق مبتكر لحجز المكاتب المشتركة ومكاتب العمل المستقلة وقاعات الاجتماعات في كبرى مدن المملكة. يتيح معاينة تفاصيل المساحة، فحص توفر القاعات بالتقويم الفوري، سداد الفاتورة إلكترونياً، وإصدار بطاقة الدخول الذكية بالـ QR Code."
    },
    "1270577": {
        "title": "شريك — منصة الغرف الصوتية والتواصل التفاعلي الاجتماعي",
        "tagline": "غرف حوارية حية، بودكاست تفاعلي، ومجتمعات صوتية بأقل استهلاك للبيانات",
        "preset": "standard",
        "theme": {"primary_color": "#7c3aed", "accent_color": "#06b6d4"},
        "desc": "تطبيق اجتماعي للغرف الصوتية الحية والمناقشات الثقافية والمهنية. مبني على بروتوكول WebRTC الصوتي فائق السرعة، مع إدارة ذكية للأذونات والمشرفين، ونظام هدايا تفاعلية وحماية كاملة للخصوصية."
    },
    "1270630": {
        "title": "بايت — منصة توصيل الأطعمة وحفظ النعمة والوجبات الفائضة",
        "tagline": "وجبات طازجة من أفضل المطاعم بخصومات حصرية وتوصيل سريع حتى بابك",
        "preset": "food",
        "theme": {"primary_color": "#ea580c", "accent_color": "#16a34a"},
        "desc": "تطبيق توصيل وجبات طعام طازجة من المطاعم والمخابز مع مبادرة مبتكرة لحفظ النعمة وبيع الوجبات الفائضة بنهاية اليوم بأسعار مخفضة. يشمل تتبع السائق لحظياً على الخريطة، سلة مشتريات ديناميكية، وبوابات دفع إلكترونية آمنة."
    }
}

for pid, info in PROJECT_DETAILS.items():
    shot1 = f"shots/{pid}_01.png"
    shot2 = f"shots/{pid}_02.png"
    shot3 = f"shots/{pid}_03.png"

    spec = {
        "project_id": pid,
        "app_name": info["title"],
        "tagline": info["tagline"],
        "preset": info["preset"],
        "theme": info["theme"],
        "description": info["desc"],
        "proof_screenshots": [
            {"title": "الشاشة الرئيسية واستعراض الخدمات والمحتوى", "path": shot1},
            {"title": "شاشة التفاصيل وخيارات التخصيص والبيانات", "path": shot2},
            {"title": "شاشة إتمام العملية أو التتبع اللحظي", "path": shot3}
        ]
    }

    spec_file = SPECS_DIR / f"{pid}.json"
    with open(spec_file, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)
    print(f"✓ Wrote spec for #{pid} -> {spec_file.name}")

    # Synchronize with running Web App API
    try:
        req = urllib.request.Request(
            f"{API_BASE_URL}/api/projects",
            data=json.dumps(spec, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            print(f"  ✓ Synced #{pid} to Web App API ({resp.status})")
    except Exception as api_err:
        print(f"  ⚠️ Web App sync skipped for #{pid}: {api_err}")

print("\n🎉 All project specs synchronized with local filesystem and Web App API!")
