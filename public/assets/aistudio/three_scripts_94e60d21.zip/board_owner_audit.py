#!/usr/bin/env python3
from smart_screenshot_auditor import calculate_dhash, dhash_similarity, pixel_similarity_ratio
"""
board_owner_audit.py — Board of Trustees & Owner Oversight Auditor
Persona: The Board Owner / Chairman of the Board of Trustees (رئيس مجلس الإدارة والمالك الأعلى للمنشأة).
Audits BOTH the Headmaster (الناظر) and the Students (الطلاب / فريق المصنع) every 20 projects.

Responsibilities:
1. Cohort Segmentation: Divides all repositories into 20-project cohorts (Epochs).
2. Student Body Performance Evaluation:
   - Yield (% Production Certified 100% vs Remediation vs Failure).
   - Invariants Adherence: Zero Emojis, Pure SVG/XML Vectors, Clean Architecture, Pixel 6 Emulator Proofs.
   - Commercial Monetization Potential (Shopify / Salla / Next.js Enterprise valuation).
3. Headmaster Rigor & Integrity Audit:
   - Evaluates the Headmaster's auditing fidelity (False Positive / False Negative detection).
   - Audits whether the Headmaster let any defect or emoji slip through.
   - Assigns a Board Grade to the Headmaster (A+, A, B, C, F).
4. Board Governance Directives & Resolutions:
   - Issues binding directives for both Students and Headmaster.
   - Dispatches executive alerts via Telegram to the Owner.
   - Saves comprehensive Markdown & JSON records in /root/big project/board_audits/.
"""

import os
import re
import sys
import json
import time
import argparse
import subprocess
import urllib.request
from pathlib import Path
from datetime import datetime

# ANSI Colors
C_RED = "\033[91m"
C_GREEN = "\033[92m"
C_YELLOW = "\033[93m"
C_BLUE = "\033[94m"
C_MAGENTA = "\033[95m"
C_CYAN = "\033[96m"
C_WHITE = "\033[97m"
C_BOLD = "\033[1m"
C_RESET = "\033[0m"

BOARD_AUDITS_DIR = Path("/root/big project/board_audits")
PENALTIES_FILE = BOARD_AUDITS_DIR / "president_penalties.json"
LIVE_PREVIEWS_DIR = Path("/root/big project/live-previews")
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "8163986542:AAEQrTJ6UA8L_DqVZpJ5stVIj2iaKHdsPf4")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "-1003208005646")

# Add /usr/local/bin to sys.path so we can import headmaster_reviewer
sys.path.insert(0, "/usr/local/bin")
try:
    import headmaster_reviewer
except ImportError:
    headmaster_reviewer = None

def send_telegram_alert(text: str) -> bool:
    """Send high-priority executive alert to the Board Owner Telegram channel."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return False
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = json.dumps({
            "chat_id": TELEGRAM_CHAT_ID,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True
        }).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except Exception as e:
        print(f"Failed to send Telegram alert: {e}")
        return False

def get_all_app_repos() -> list:
    """Fetch all app repositories from GitHub sorted chronologically."""
    try:
        res = subprocess.run([
            "gh", "repo", "list", "hmoushim0-cloud", "--limit", "100", "--json", "name,createdAt"
        ], capture_output=True, text=True, check=True)
        repos = json.loads(res.stdout)
        apps = [r for r in repos if r["name"].startswith("app-")]
        # Sort chronologically (oldest first)
        apps.sort(key=lambda x: x["createdAt"])
        return apps
    except Exception as e:
        print(f"Error fetching repos: {e}")
        return []

def partition_into_cohorts(repos: list, cohort_size: int = 20) -> list:
    """Partition repos into 20-project cohorts."""
    cohorts = []
    for i in range(0, len(repos), cohort_size):
        cohort_repos = repos[i:i + cohort_size]
        cohort_number = (i // cohort_size) + 1
        is_complete = len(cohort_repos) == cohort_size
        cohorts.append({
            "cohort_number": cohort_number,
            "start_index": i + 1,
            "end_index": i + len(cohort_repos),
            "is_complete": is_complete,
            "target_size": cohort_size,
            "actual_size": len(cohort_repos),
            "repos": cohort_repos
        })
    return cohorts

def audit_cohort_students(cohort: dict) -> dict:
    """Audit all students (app repos) in the cohort using Headmaster criteria."""
    results = []
    total = len(cohort["repos"])
    for idx, r in enumerate(cohort["repos"]):
        rname = r["name"]
        print(f"  [{idx+1}/{total}] Auditing student repo {rname}...", flush=True)
        if headmaster_reviewer:
            audit = headmaster_reviewer.audit_single_app(rname)
        else:
            audit = {"repo": rname, "score": 0, "penalties": ["headmaster_reviewer module missing"]}
        audit["createdAt"] = r.get("createdAt", "")
        results.append(audit)

    # Compute metrics
    scores = [r["score"] for r in results]
    avg_score = round(sum(scores) / len(scores), 1) if scores else 0
    certified = [r for r in results if r["score"] >= 95]
    remediation = [r for r in results if 70 <= r["score"] < 95]
    defective = [r for r in results if r["score"] < 70]

    # Sensei invariants check across cohort
    zero_emoji_compliant = sum(1 for r in results if not any("emoji" in p.lower() for p in r.get("penalties", [])))
    clean_arch_compliant = sum(1 for r in results if not any("architectural layering" in p.lower() for p in r.get("penalties", [])))
    native_shots_compliant = sum(1 for r in results if any("1080x2400" in s for s in r.get("strengths", [])))

    # Commercial Valuation
    certified_count = len(certified)
    val_mvp_sar = certified_count * 3500
    val_shopify_sar = certified_count * 8500
    val_nextjs_sar = certified_count * 15000

    # Student Body Overall Grade
    if avg_score >= 95 and len(certified) == len(results):
        student_grade = "A+ (Institutional Perfection)"
    elif avg_score >= 85:
        student_grade = "A (Exemplary Production)"
    elif avg_score >= 70:
        student_grade = "B (Passable with Active Remediation)"
    elif avg_score >= 50:
        student_grade = "C (High Defect Rate — Immediate Intervention Required)"
    else:
        student_grade = "F (Factory Disciplinary Failure)"

    return {
        "cohort_number": cohort["cohort_number"],
        "total_projects": len(results),
        "is_complete": cohort["is_complete"],
        "avg_score": avg_score,
        "student_grade": student_grade,
        "certified_count": len(certified),
        "remediation_count": len(remediation),
        "defective_count": len(defective),
        "zero_emoji_compliance_pct": round((zero_emoji_compliant / len(results)) * 100, 1),
        "clean_arch_compliance_pct": round((clean_arch_compliant / len(results)) * 100, 1),
        "native_shots_compliance_pct": round((native_shots_compliant / len(results)) * 100, 1),
        "valuation": {
            "mvp_sar": val_mvp_sar,
            "shopify_sar": val_shopify_sar,
            "nextjs_sar": val_nextjs_sar
        },
        "results": results
    }

def audit_headmaster_performance(cohort_audit: dict) -> dict:
    """Audit the Headmaster (الناظر): independent AST/Pixel inspection + President Decrees."""
    headmaster_score = 100
    headmaster_penalties = []
    headmaster_commendations = []

    results = cohort_audit["results"]

    # 1. Independent AST & Pixel Duplicate Screen Verification (No Circular Trust!)
    false_positives = 0
    shots_dir = LIVE_PREVIEWS_DIR / "shots"

    for r in results:
        pid = r.get("project_id", r["repo"].replace("app-", ""))
        score = r.get("score", 0)

        # Independent pixel duplicate fraud check on certified apps
        if score >= 90:
            s1 = shots_dir / f"{pid}_01.png"
            s2 = shots_dir / f"{pid}_02.png"
            s3 = shots_dir / f"{pid}_03.png"

            if s1.exists() and s2.exists() and s3.exists():
                h1 = calculate_dhash(s1)
                h2 = calculate_dhash(s2)
                h3 = calculate_dhash(s3)
                sim_12 = dhash_similarity(h1, h2)
                sim_23 = dhash_similarity(h2, h3)
                p_sim12 = pixel_similarity_ratio(s1, s2)
                p_sim23 = pixel_similarity_ratio(s2, s3)

                if (sim_12 > 80.0 and p_sim12 > 80.0) or (sim_23 > 80.0 and p_sim23 > 80.0):
                    false_positives += 1
                    headmaster_penalties.append(
                        f"CRITICAL Rubber-Stamp Strike: Headmaster certified app-{pid} but independent pixel audit "
                        f"detected DUPLICATE SCREEN CAPTURE FRAUD (>80% identical screenshots) (-30)"
                    )
                    headmaster_score -= 30

    if false_positives == 0:
        headmaster_commendations.append("Independent Forensic Verification: Zero duplicate screenshot fraud certified by Headmaster")

    # 2. Supreme President's Royal Decrees & Penalty Ledger Enforcement
    if PENALTIES_FILE.exists():
        try:
            penalties_raw = json.loads(PENALTIES_FILE.read_text(encoding="utf-8"))
            cohort_pids = [r.get("project_id", r["repo"].replace("app-", "")) for r in results]
            
            if isinstance(penalties_raw, dict):
                penalties_list = penalties_raw.get("headmaster_penalties", [])
            elif isinstance(penalties_raw, list):
                penalties_list = penalties_raw
            else:
                penalties_list = []
                
            # Find any penalties matching this cohort's projects
            relevant_penalties = [p for p in penalties_list if isinstance(p, dict) and p.get("project_id") in cohort_pids]
            for p in relevant_penalties:
                pts = p.get("penalty_pts", p.get("penalty_points", 25))
                headmaster_score -= pts
                headmaster_penalties.append(
                    f"👑 ROYAL PRESIDENTIAL STRIKE: Headmaster penalized -{pts} pts for project #{p['project_id']} "
                    f"refused by The Supreme President! Reason: «{p.get('reason', '')}»"
                )
        except Exception as e:
            print(f"Error reading president penalties: {e}")

    # 3. Disciplinary Rigor: Headmaster caught weak code
    defective_caught = sum(1 for r in results if r.get("score", 0) < 70)
    if defective_caught > 0:
        headmaster_commendations.append(
            f"Ruthless Disciplinary Action: Headmaster struck down {defective_caught} subpar apps with the Stick"
        )

    headmaster_score = max(0, min(100, headmaster_score))

    if headmaster_score >= 95:
        headmaster_grade = "A+ (Vigilant, Ruthless, & Impeccable Oversight)"
    elif headmaster_score >= 85:
        headmaster_grade = "A (Strong & Reliable Discipline)"
    elif headmaster_score >= 75:
        headmaster_grade = "B (Fair Oversight, Minor Follow-up Required)"
    elif headmaster_score >= 60:
        headmaster_grade = "C (Permissive / Leniency Warning)"
    else:
        headmaster_grade = "F (Gross Negligence — Dismissal Recommended by The President)"

    return {
        "headmaster_score": headmaster_score,
        "headmaster_grade": headmaster_grade,
        "headmaster_commendations": headmaster_commendations,
        "headmaster_penalties": headmaster_penalties,
        "false_positives_detected": false_positives
    }

def generate_board_report(cohort_audit: dict, headmaster_audit: dict) -> tuple[str, str]:
    """Generate ANSI terminal string and Markdown document for Board Governance Report."""
    c_num = cohort_audit["cohort_number"]
    total = cohort_audit["total_projects"]
    avg = cohort_audit["avg_score"]
    c_grade = cohort_audit["student_grade"]
    h_score = headmaster_audit["headmaster_score"]
    h_grade = headmaster_audit["headmaster_grade"]
    val = cohort_audit["valuation"]

    # Terminal Report
    term = []
    term.append(f"\n{C_BOLD}{C_MAGENTA}======================================================================{C_RESET}")
    term.append(f"{C_BOLD}{C_WHITE}🏛️ BOARD OWNER EXECUTIVE GOVERNANCE AUDIT — COHORT #{c_num}{C_RESET}")
    term.append(f"{C_BOLD}{C_CYAN}High-Level Oversight of the Headmaster & Student Body (Every 20 Projects){C_RESET}")
    term.append(f"{C_BOLD}{C_MAGENTA}======================================================================{C_RESET}\n")

    term.append(f"📋 {C_BOLD}COHORT STATUS:{C_RESET} {total}/20 Projects {'(Complete Milestone ✅)' if cohort_audit['is_complete'] else '(Active Batch in Progress ⏳)'}")
    term.append(f"📅 {C_BOLD}AUDIT TIMESTAMP:{C_RESET} {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    term.append(f"💰 {C_BOLD}CERTIFIED PORTFOLIO COMMERCIAL VALUE:{C_RESET}")
    term.append(f"   • MVP Turnkey (3,500 SAR):       {C_GREEN}{val['mvp_sar']:,} SAR{C_RESET}")
    term.append(f"   • Shopify Headless (8,500 SAR):   {C_GREEN}{val['shopify_sar']:,} SAR{C_RESET}")
    term.append(f"   • Next.js Enterprise (15,000 SAR): {C_GREEN}{val['nextjs_sar']:,} SAR{C_RESET}\n")

    term.append(f"{C_BOLD}----------------------------------------------------------------------{C_RESET}")
    term.append(f"👨‍🏫 {C_BOLD}HEADMASTER AUDIT (تقييم ناظر المدرسة ذو العصا):{C_RESET}")
    term.append(f"   • Rigor Score: {C_GREEN if h_score >= 90 else C_YELLOW}{h_score}/100{C_RESET}")
    term.append(f"   • Board Rating: {C_BOLD}{h_grade}{C_RESET}")
    for comm in headmaster_audit["headmaster_commendations"]:
        term.append(f"     {C_GREEN}✓ {comm}{C_RESET}")
    for pen in headmaster_audit["headmaster_penalties"]:
        term.append(f"     {C_RED}❌ {pen}{C_RESET}")

    term.append(f"\n{C_BOLD}----------------------------------------------------------------------{C_RESET}")
    term.append(f"🎓 {C_BOLD}STUDENT BODY AUDIT (تقييم الطلاب وفريق المصنع):{C_RESET}")
    term.append(f"   • Mean Cohort Score: {C_GREEN if avg >= 85 else (C_YELLOW if avg >= 70 else C_RED)}{avg}%{C_RESET}")
    term.append(f"   • Student Body Rating: {C_BOLD}{c_grade}{C_RESET}")
    term.append(f"   • Production Certified (100% 🟢): {cohort_audit['certified_count']} apps")
    term.append(f"   • Remediation Required (70-90% 🟡): {cohort_audit['remediation_count']} apps")
    term.append(f"   • Defective / Struck Down (<70% 🔴): {cohort_audit['defective_count']} apps")
    term.append(f"   • Zero-Emoji Vector Compliance:  {cohort_audit['zero_emoji_compliance_pct']}%")
    term.append(f"   • Clean Architecture Compliance:  {cohort_audit['clean_arch_compliance_pct']}%")
    term.append(f"   • Native Pixel 6 Emulator Proofs: {cohort_audit['native_shots_compliance_pct']}%\n")

    term.append(f"{C_BOLD}======================================================================{C_RESET}")
    term.append(f"📜 {C_BOLD}BOARD OWNER GOVERNANCE DIRECTIVES (قرارات مجلس الإدارة الملزمة):{C_RESET}")
    term.append(f"{C_BOLD}======================================================================{C_RESET}")
    term.append(f"1. {C_CYAN}[Directive to Students]{C_RESET} Strictly maintain Zero Emojis and Clean Architecture on all future generations.")
    term.append(f"2. {C_CYAN}[Directive to Headmaster]{C_RESET} Continue wielding the stick against any web mockups or incomplete wrapper configurations.")
    term.append(f"3. {C_CYAN}[Directive for Remediation]{C_RESET} Automatically trigger cloud emulator runs for all apps scoring between 70% and 94% to achieve 100% certification.")
    term.append(f"4. {C_CYAN}[Commercial Mandate]{C_RESET} Ensure dual-platform KMP switchers and commercial pricing tiers are published on CDN for every certified app.\n")

    term_output = "\n".join(term)

    # Markdown Document
    md = []
    md.append(f"# 🏛️ تقرير تدقيق مجلس الإدارة والمالك الأعلى — الدفعة رقم {c_num} (Cohort #{c_num})")
    md.append(f"\n> **تاريخ التقييم:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | **حالة الدفعة:** {total}/20 مشروعاً ({'مكتملة بالكامل' if cohort_audit['is_complete'] else 'قيد التنفيذ النشط'})")
    md.append("\n---\n")

    md.append("## 1. تقييم ناظر المدرسة (Headmaster Performance Review)")
    md.append(f"- **درجة دقة المراجعة:** `{h_score} / 100`")
    md.append(f"- **التقييم المؤسسي للناظر:** **{h_grade}**")
    md.append("- **ملاحظات التدقيق على الناظر:**")
    for comm in headmaster_audit["headmaster_commendations"]:
        md.append(f"  - ✅ {comm}")
    for pen in headmaster_audit["headmaster_penalties"]:
        md.append(f"  - ❌ {pen}")

    md.append("\n---\n")
    md.append("## 2. تقييم الطلاب ومنظومة المصنع (Student Body & Factory Engine Review)")
    md.append(f"- **المعدل العام للدفعة:** `{avg}%`")
    md.append(f"- **التقدير الأكاديمي للطلاب:** **{c_grade}**")
    md.append(f"- **المشاريع المعتمدة للإنتاج (100% 🟢):** `{cohort_audit['certified_count']}`")
    md.append(f"- **المشاريع المحتاجة لاستدراك (70-90% 🟡):** `{cohort_audit['remediation_count']}`")
    md.append(f"- **المشاريع المرفوضة بالعصا (<70% 🔴):** `{cohort_audit['defective_count']}`")
    md.append(f"- **نسبة الالتزام بقاعدة صفر إيموجي (Pure Vectors):** `{cohort_audit['zero_emoji_compliance_pct']}%`")
    md.append(f"- **نسبة الالتزام بمعمارية Clean Architecture:** `{cohort_audit['clean_arch_compliance_pct']}%`")
    md.append(f"- **نسبة التحقق بلقطات تشغيل المحاكي السحابي الحقيقي (1080×2400):** `{cohort_audit['native_shots_compliance_pct']}%`")

    md.append("\n---\n")
    md.append("## 3. التقييم المالي والتجاري للدفعة (Commercial Portfolio Valuation)")
    md.append("| المستوى التجاري | القيمة لكل تطبيق | إجمالي قيمة الدفعة المعتمدة |")
    md.append("| :--- | :---: | :---: |")
    md.append(f"| **KMP MVP Turnkey** | 3,500 ر.س ($950) | **{val['mvp_sar']:,} ر.س** |")
    md.append(f"| **Shopify / Salla Headless** | 8,500 ر.س ($2,250) | **{val['shopify_sar']:,} ر.س** |")
    md.append(f"| **Full-Stack Next.js 15 Suite** | 15,000 ر.س ($4,000) | **{val['nextjs_sar']:,} ر.س** |")

    md.append("\n---\n")
    md.append("## 4. جدول نتائج المشاريع في الدفعة (Cohort Project Ledger)")
    md.append("| المشروع | النتيجة | الحالة | العيوب المرصودة | تاريخ الإنشاء |")
    md.append("| :--- | :---: | :--- | :---: | :--- |")
    for r in cohort_audit["results"]:
        md.append(f"| [`{r['repo']}`](https://github.com/hmoushim0-cloud/{r['repo']}) | {r['score']}% {r['badge']} | {r['verdict']} | {len(r.get('penalties', []))} | {r.get('createdAt', '')[:10]} |")

    md.append("\n---\n")
    md.append("## 5. قرارات مجلس الإدارة الإلزامية (Board Governance Directives)")
    md.append("1. **إلزامية معمارية Clean Architecture:** يمنع دمج أي مشروع لا يحتوي على فصل صريح بين `model/` و `data/` و `ui/`.")
    md.append("2. **الاستمرار بقاعدة سينسي الصارمة:** حظر كامل للإيموجيات في كافة الملفات ونماذج البيانات واستخدام متجهات الـ SVG حصراً.")
    md.append("3. **مكافأة الناظر الصارم:** تثبيت وتفعيل صلاحيات الناظر بالعصا لمواصلة شطب أي مشاريع تستخدم إطارات الويب القديمة (`demo/`).")
    md.append("4. **اعتماد الواجهة المزدوجة KMP:** إلزامية ربط كل تطبيق معتمد بـ [منصة المعاينة الحية](https://hmoushim0-cloud.github.io/live-previews/) بإطاري الأندرويد والآيفون.")

    md_output = "\n".join(md)
    return term_output, md_output

def execute_cohort_audit(cohort_index: int = None, send_telegram: bool = True):
    """Run audit on a specific cohort or all cohorts."""
    all_repos = get_all_app_repos()
    cohorts = partition_into_cohorts(all_repos, cohort_size=20)
    
    if not cohorts:
        print("No app repositories found.")
        return

    target_cohorts = cohorts
    if cohort_index is not None and 1 <= cohort_index <= len(cohorts):
        target_cohorts = [cohorts[cohort_index - 1]]

    for c in target_cohorts:
        c_num = c["cohort_number"]
        print(f"\n🔍 Auditing Cohort #{c_num} ({c['actual_size']} apps)...")
        c_audit = audit_cohort_students(c)
        h_audit = audit_headmaster_performance(c_audit)
        
        term_text, md_text = generate_board_report(c_audit, h_audit)
        print(term_text)

        # Save files
        BOARD_AUDITS_DIR.mkdir(parents=True, exist_ok=True)
        json_path = BOARD_AUDITS_DIR / f"cohort_{c_num}.json"
        md_path = BOARD_AUDITS_DIR / f"COHORT_{c_num}_GOVERNANCE_REPORT.md"

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({
                "cohort": c_audit,
                "headmaster": h_audit,
                "timestamp": datetime.now().isoformat()
            }, f, indent=2, ensure_ascii=False)

        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md_text)

        print(f"💾 Report saved: {md_path}")
        print(f"💾 Data saved: {json_path}")

        # Send Telegram Summary
        if send_telegram:
            tg_msg = (
                f"🏛️ <b>[مجلس الإدارة - Board Owner Audit]</b>\n"
                f"📊 <b>تقرير حوكمة الدفعة رقم #{c_num} ({c['actual_size']}/20 مشروع)</b>\n\n"
                f"👨‍🏫 <b>تقييم ناظر المدرسة:</b> {h_audit['headmaster_score']}/100 ({h_audit['headmaster_grade']})\n"
                f"🎓 <b>تقييم الطلاب:</b> {c_audit['avg_score']}% ({c_audit['student_grade']})\n"
                f"🟢 <b>معتمد للإنتاج (100%):</b> {c_audit['certified_count']} تطبيقات\n"
                f"🟡 <b>يحتاج استدراك:</b> {c_audit['remediation_count']} تطبيقات\n"
                f"🔴 <b>راسب / مرفوض:</b> {c_audit['defective_count']} تطبيقات\n\n"
                f"💰 <b>القيمة التجارية للمشاريع المعتمدة:</b>\n"
                f"• MVP Turnkey: {c_audit['valuation']['mvp_sar']:,} ر.س\n"
                f"• Shopify Headless: {c_audit['valuation']['shopify_sar']:,} ر.س\n"
                f"• Next.js Enterprise: {c_audit['valuation']['nextjs_sar']:,} ر.س\n\n"
                f"✨ <i>الالتزام بصفر إيموجي: {c_audit['zero_emoji_compliance_pct']}% | المعمارية النظيفة: {c_audit['clean_arch_compliance_pct']}%</i>"
            )
            send_telegram_alert(tg_msg)
            print("📲 Telegram Executive Notification Dispatched!")

def check_and_audit_if_milestone(send_telegram: bool = True):
    """Check if total repos reached a multiple of 20 and run audit."""
    repos = get_all_app_repos()
    total = len(repos)
    print(f"Current total app repositories: {total}")
    
    # Check completed cohorts
    completed_cohorts = total // 20
    remainder = total % 20
    print(f"Completed cohorts (groups of 20): {completed_cohorts}, Remaining in current: {remainder}")

    marker_file = BOARD_AUDITS_DIR / ".last_audited_count"
    last_count = 0
    if marker_file.exists():
        try:
            last_count = int(marker_file.read_text().strip())
        except Exception:
            last_count = 0

    if total >= last_count + 20 or (completed_cohorts > 0 and last_count < completed_cohorts * 20):
        print(f"🎯 Milestone reached! Auditing cohort {completed_cohorts}...")
        execute_cohort_audit(completed_cohorts, send_telegram=send_telegram)
        marker_file.write_text(str(completed_cohorts * 20))
    else:
        print(f"ℹ️ Next milestone at {(completed_cohorts + 1) * 20} projects ({20 - remainder} projects remaining).")
        # Run latest cohort anyway to show current health
        execute_cohort_audit(len(partition_into_cohorts(repos)), send_telegram=send_telegram)

def main():
    parser = argparse.ArgumentParser(description="Board Owner Audit System (Every 20 Projects)")
    parser.add_argument("--cohort", type=int, help="Specific cohort number to audit (e.g. 1, 2)")
    parser.add_argument("--all", action="store_true", help="Audit all cohorts")
    parser.add_argument("--latest", action="store_true", help="Audit the latest cohort")
    parser.add_argument("--milestone", action="store_true", help="Check and audit if 20-project milestone reached")
    parser.add_argument("--no-telegram", action="store_true", help="Disable Telegram notifications")
    
    args = parser.parse_args()
    send_tg = not args.no_telegram

    if args.milestone:
        check_and_audit_if_milestone(send_telegram=send_tg)
    elif args.all:
        execute_cohort_audit(cohort_index=None, send_telegram=send_tg)
    elif args.latest:
        repos = get_all_app_repos()
        cohorts = partition_into_cohorts(repos)
        execute_cohort_audit(cohort_index=len(cohorts), send_telegram=send_tg)
    elif args.cohort:
        execute_cohort_audit(cohort_index=args.cohort, send_telegram=send_tg)
    else:
        # Default: audit all cohorts
        execute_cohort_audit(cohort_index=None, send_telegram=send_tg)

if __name__ == "__main__":
    main()
