#!/usr/bin/env python3
"""
Mostaql Automated Scout Daemon & Monitor (Stealth & Smart Cooldown Edition)
Features:
- Randomized human-like polling intervals (20s to 120s)
- Automatic rate limiter: max 5 alerts/hour -> triggers a 2-hour cooldown
- SQLite deduplication (zero duplicate alerts)
- Telegram instant notification dispatch
- Gemini AI Proposal generator
"""

import argparse
import functools
import html
import json
import os
import random
import re
import sqlite3
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta

print_flush = functools.partial(print, flush=True)

# Auto-load .env if present
ENV_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
if os.path.exists(ENV_PATH):
    with open(ENV_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                k, v = k.strip(), v.strip().strip('"').strip("'")
                if k not in os.environ:
                    os.environ[k] = v

DB_PATH = os.path.expanduser("~/.mostaql_scout.db")

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/122.0.0.0 Safari/537.36"
]

def get_headers():
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Referer": "https://mostaql.com/"
    }

def init_db(db_path=DB_PATH):
    """Initialize SQLite database for tracking seen projects and alert history."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS seen_projects (
            id TEXT PRIMARY KEY,
            title TEXT,
            url TEXT,
            client TEXT,
            description TEXT,
            first_seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            alert_sent INTEGER DEFAULT 0
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alert_history (
            project_id TEXT,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn

def is_project_seen(conn, project_id):
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM seen_projects WHERE id = ?", (str(project_id),))
    return cur.fetchone() is not None

def mark_project_seen(conn, p, alert_sent=1):
    cur = conn.cursor()
    cur.execute("""
        INSERT OR IGNORE INTO seen_projects (id, title, url, client, description, alert_sent)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (p["id"], p["title"], p["url"], p["client"], p["description"], alert_sent))
    if alert_sent:
        cur.execute("INSERT INTO alert_history (project_id) VALUES (?)", (p["id"],))
    conn.commit()

def count_recent_alerts(conn, hours=1):
    """Count how many alerts were dispatched in the past X hours."""
    cur = conn.cursor()
    cutoff = datetime.now() - timedelta(hours=hours)
    cur.execute("SELECT count(*) FROM alert_history WHERE sent_at >= ?", (cutoff.strftime("%Y-%m-%d %H:%M:%S"),))
    return cur.fetchone()[0]

def fetch_projects(keyword=None, skill_slug=None):
    """Fetch current projects from Mostaql with randomized browser fingerprint."""
    params = {}
    if keyword:
        params["keyword"] = keyword
    if skill_slug:
        params["skills"] = skill_slug

    query_str = urllib.parse.urlencode(params)
    url = f"https://mostaql.com/projects?{query_str}" if query_str else "https://mostaql.com/projects"

    req = urllib.request.Request(url, headers=get_headers())
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            page_html = resp.read().decode("utf-8", errors="ignore")
    except Exception as e:
        sys.stderr.write(f"[{datetime.now().strftime('%H:%M:%S')}] Fetch error ({url}): {e}\n")
        return []

    rows = re.findall(r"<tr[^>]*class=[\x27\"][^\x27\"]*project-row[^\x27\"]*[\x27\"][^>]*>(.*?)</tr>", page_html, re.DOTALL)
    projects = []

    for r in rows:
        title_match = re.search(r"<a[^>]*href=[\x27\"]([^\x27\"]*/project/(\d+)[^\x27\"]*)[\x27\"][^>]*>(.*?)</a>", r, re.DOTALL)
        if title_match:
            plink = title_match.group(1)
            pid = title_match.group(2)
            if not plink.startswith("http"):
                plink = "https://mostaql.com" + plink
            raw_title = title_match.group(0)
            inner_title = re.search(r">([^<]+)<", raw_title)
            ptitle = html.unescape(inner_title.group(1).strip()) if inner_title else "Project"
        else:
            continue

        meta_items = re.findall(r"<li[^>]*>(.*?)</li>", r, re.DOTALL)
        meta_cleaned = [html.unescape(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", m)).strip()) for m in meta_items if re.sub(r"<[^>]+>", "", m).strip()]
        clean_meta = [m for m in meta_cleaned if not any(x in m for x in ["أضف إلى المفضلة", "تبليغ"])]
        
        client_name = clean_meta[0] if len(clean_meta) > 0 else "Unknown"
        time_posted = clean_meta[1] if len(clean_meta) > 1 else ""
        offers_count = clean_meta[2] if len(clean_meta) > 2 else ""

        desc_match = re.search(r"<p[^>]*class=[\x27\"][^\x27\"]*project__brief[^\x27\"]*[\x27\"][^>]*>(.*?)</p>", r, re.DOTALL) or re.search(r"<p[^>]*>(.*?)</p>", r, re.DOTALL)
        pdesc = html.unescape(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", desc_match.group(1))).strip()) if desc_match else ""

        projects.append({
            "id": pid,
            "title": ptitle,
            "url": plink,
            "client": client_name,
            "time_posted": time_posted,
            "offers": offers_count,
            "description": pdesc
        })

    return projects

def classify_preset(title, desc=""):
    text = (title + " " + desc).lower()
    if any(k in text for k in ["مطعم", "طعام", "وجبات", "شاورما", "برجر", "كافيه", "قهوة", "مأكولات", "توصيل"]):
        return "food"
    if any(k in text for k in ["متجر", "تجارة", "سلة", "منتجات", "شراء", "عطور", "ملابس", "تسوق", "إلكتروني"]):
        return "ecommerce"
    if any(k in text for k in ["حجز", "صيانة", "غسيل", "تنظيف", "عيادة", "خدمات", "استشارات", "طبي"]):
        return "services"
    return "standard"

def generate_ai_proposal(project, gemini_api_key=None, my_skills="Full-Stack & Mobile App Developer (Android, Flutter, iOS)"):
    if not gemini_api_key:
        return None

    prompt = f"""
أنت كاتب عروض محترف لمشاريع العمل الحر على منصة مستقل. اكتب عرضاً مقنعاً ومباشراً للمشروع التالي باللغة العربية:

عنوان المشروع: {project['title']}
صاحب المشروع: {project['client']}
تفاصيل المشروع: {project['description']}

مهارات المستقل: {my_skills}

هيكل العرض:
1. تحية مهنية بدون مقدمات طويلة وإظهار فهم دقيق لاحتياج العميل.
2. خطة العمل المباشرة والتقنيات المقترحة للتنفيذ.
3. التزام بالجودة والدعم الفني ومدة تسليم واضحة.
4. دعوة لبدء المحادثة ومناقشة التفاصيل.
اكتب العرض بصيغة جاهزة للنسخ مباشرة بدون علامات تنصيص إضافية.
"""
    api_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={gemini_api_key}"
    payload = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}]
    }).encode("utf-8")

    req = urllib.request.Request(api_url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        sys.stderr.write(f"AI Proposal generation error: {e}\n")
        return None

def send_telegram_alert(bot_token, chat_id, project, proposal=None):
    msg = f"🚀 <b>مشروع جديد على مستقل!</b>\n\n"
    msg += f"📌 <b>العنوان:</b> <a href='{project['url']}'>{html.escape(project['title'])}</a>\n"
    msg += f"👤 <b>العميل:</b> {html.escape(project['client'])} | 🕒 {html.escape(project['time_posted'])}\n"
    msg += f"💬 <b>العروض الحالية:</b> {html.escape(project['offers'])}\n\n"
    msg += f"📝 <b>نبذة عن المشروع:</b>\n<i>{html.escape(project['description'][:280])}...</i>\n"

    if proposal:
        msg += f"\n💡 <b>مسودة العرض المقترح (AI):</b>\n<code>{html.escape(proposal)}</code>\n"

    msg += f"\n👉 <a href='{project['url']}'>اضغط لفتح المشروع في مستقل والتقديم</a>"

    tg_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    payload = json.dumps({
        "chat_id": chat_id,
        "text": msg,
        "parse_mode": "HTML",
        "disable_web_page_preview": False
    }).encode("utf-8")

    req = urllib.request.Request(tg_url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except Exception as e:
        sys.stderr.write(f"Telegram error: {e}\n")
        return False

def monitor_loop(skills=None, keyword=None, min_interval=20, max_interval=120, max_alerts_hour=5, cooldown_hours=2,
                 bot_token=None, chat_id=None, gemini_api_key=None, max_iterations=None, send_test=False):
    conn = init_db()
    print_flush(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 🚀 Mostaql Scout Monitor Started (Stealth Mode)")
    print_flush(f"Intervals: Random {min_interval}s – {max_interval}s | Max Alerts/Hour: {max_alerts_hour} | Cooldown: {cooldown_hours}h")
    print_flush(f"Target Filters: Skills={skills}, Keyword={keyword}")
    if bot_token and chat_id:
        print_flush(f"Telegram Alerts: ENABLED (Chat ID: {chat_id})")
    if gemini_api_key:
        print_flush("AI Proposal Engine: ENABLED")
    print_flush("=" * 80)

    # Seed check across general feed and target skills
    targets = [None]
    if skills:
        targets.extend(skills)

    for target_skill in targets:
        seed_list = fetch_projects(keyword=keyword, skill_slug=target_skill)
        for p in seed_list:
            if not is_project_seen(conn, p["id"]):
                mark_project_seen(conn, p, alert_sent=0)

    cur = conn.cursor()
    cur.execute("SELECT count(*) FROM seen_projects")
    print_flush(f"Database initialized with {cur.fetchone()[0]} cached projects.")

    iteration = 0
    try:
        while True:
            iteration += 1
            if max_iterations and iteration > max_iterations:
                break

            # Calculate random sleep duration
            sleep_duration = random.randint(min_interval, max_interval)
            time.sleep(sleep_duration)

            # Check Rate Limit / Cooldown rule
            recent_alerts = count_recent_alerts(conn, hours=1)
            if recent_alerts >= max_alerts_hour:
                cooldown_secs = int(cooldown_hours * 3600)
                cooldown_end = datetime.now() + timedelta(seconds=cooldown_secs)
                print_flush(f"\n[{datetime.now().strftime('%H:%M:%S')}] 🛑 Cooldown Triggered: {recent_alerts} alerts sent in last hour.")
                print_flush(f"Sleeping for {cooldown_hours} hours until {cooldown_end.strftime('%H:%M:%S')} to maintain human behavior...\n")
                
                if bot_token and chat_id:
                    status_msg = f"⏳ <b>Mostaql Scout Cooldown Active</b>\nReached {recent_alerts} alerts in 1 hour. Pausing for {cooldown_hours} hours to preserve account stealth."
                    tg_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
                    payload = json.dumps({"chat_id": chat_id, "text": status_msg, "parse_mode": "HTML"}).encode("utf-8")
                    try:
                        urllib.request.urlopen(urllib.request.Request(tg_url, data=payload, headers={"Content-Type": "application/json"}), timeout=10)
                    except Exception:
                        pass

                time.sleep(cooldown_secs)
                print_flush(f"[{datetime.now().strftime('%H:%M:%S')}] 🟢 Cooldown expired. Resuming scout monitoring...")
                continue

            # Poll feeds
            for target_skill in targets:
                current_projects = fetch_projects(keyword=keyword, skill_slug=target_skill)
                
                for p in reversed(current_projects):
                    if not is_project_seen(conn, p["id"]):
                        timestamp = datetime.now().strftime("%H:%M:%S")
                        print_flush(f"\n[{timestamp}] 🔔 NEW PROJECT POSTED: #{p['id']} - {p['title']}")
                        print_flush(f"URL: {p['url']}")
                        print_flush(f"Client: {p['client']} | Offers: {p['offers']}")
                        
                        # 🏭 Trigger Autonomous Ephemeral Factory via OmniRoute
                        preset = classify_preset(p["title"], p.get("description", ""))
                        brief = f"{p['title']}. {p.get('description', '')}"[:350]
                        print_flush(f"🚀 Triggering Autonomous Factory for #{p['id']} ({preset})...")
                        try:
                            import subprocess
                            subprocess.Popen([
                                "/usr/local/bin/factory_worker.sh",
                                str(p["id"]),
                                preset,
                                brief
                            ])
                            print_flush(f"✓ Factory dispatched. Live preview and Telegram delivery in progress...")
                        except Exception as fe:
                            print_flush(f"⚠️ Factory trigger error: {fe}")

                        mark_project_seen(conn, p, alert_sent=1)

            # Heartbeat print every 5 cycles
            if iteration % 5 == 0:
                print_flush(f"[{datetime.now().strftime('%H:%M:%S')}] 💓 Heartbeat: Scout active (next check in {random.randint(min_interval, max_interval)}s).")

    except KeyboardInterrupt:
        print_flush("\nScout monitor stopped by user.")
    finally:
        conn.close()

def main():
    parser = argparse.ArgumentParser(description="Mostaql Continuous Scout Monitor (Stealth Edition)")
    parser.add_argument("--skill", "-s", nargs="*", default=os.getenv("DEFAULT_SKILLS", "android,flutter").split(","), help="Skill slugs")
    parser.add_argument("--keyword", "-k", type=str, help="Keyword filter")
    parser.add_argument("--min-interval", type=int, default=int(os.getenv("MIN_INTERVAL_SECONDS", 20)), help="Min interval in seconds (default: 20)")
    parser.add_argument("--max-interval", type=int, default=int(os.getenv("MAX_INTERVAL_SECONDS", 120)), help="Max interval in seconds (default: 120)")
    parser.add_argument("--max-alerts-hour", type=int, default=int(os.getenv("MAX_ALERTS_PER_HOUR", 5)), help="Max alerts in 1 hour before cooldown (default: 5)")
    parser.add_argument("--cooldown-hours", type=float, default=float(os.getenv("COOLDOWN_HOURS", 2.0)), help="Cooldown in hours if threshold reached (default: 2.0)")
    parser.add_argument("--telegram-token", type=str, default=os.getenv("TELEGRAM_BOT_TOKEN"), help="Telegram Bot Token")
    parser.add_argument("--telegram-chat-id", type=str, default=os.getenv("TELEGRAM_CHAT_ID"), help="Telegram Chat ID")
    parser.add_argument("--gemini-api-key", type=str, default=os.getenv("GEMINI_API_KEY"), help="Google Gemini API Key")
    parser.add_argument("--send-test", action="store_true", help="Send a sample project alert and exit")
    parser.add_argument("--test-run", action="store_true", help="Perform a single test check and exit")
    args = parser.parse_args()

    max_iters = 1 if (args.test_run or args.send_test) else None
    monitor_loop(
        skills=args.skill,
        keyword=args.keyword,
        min_interval=args.min_interval,
        max_interval=args.max_interval,
        max_alerts_hour=args.max_alerts_hour,
        cooldown_hours=args.cooldown_hours,
        bot_token=args.telegram_token,
        chat_id=args.telegram_chat_id,
        gemini_api_key=args.gemini_api_key,
        max_iterations=max_iters,
        send_test=args.send_test
    )

if __name__ == "__main__":
    main()
